import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calcExpNeeded,
  getBiomeForFloor,
  calcSkillEffect,
  getShopInventory,
  SKILL_DEFINITIONS,
  HERO_CLASSES,
  GEAR_DROP_POOL,
  rollEquipmentDrop,
  generateRandomEvent,
  getInitialSkillsForClass,
  isSkillUnlocked,
  midiToFreq,
  getMusicThemeForFloor
} from './rules';

test('getBiomeForFloor routes correctly to 4 distinct biomes with pleasing background gradients', () => {
  const b1 = getBiomeForFloor(1);
  assert.equal(b1.id, 'catacombs');
  assert.ok(b1.bgGrad.includes('radial-gradient'));
  assert.ok(b1.cardBg);

  const b4 = getBiomeForFloor(4);
  assert.equal(b4.id, 'fungal_depths');
  assert.ok(b4.bgGrad.includes('radial-gradient'));

  const b8 = getBiomeForFloor(8);
  assert.equal(b8.id, 'magma_rift');

  const b10 = getBiomeForFloor(10);
  assert.equal(b10.id, 'pantheon');
});

test('SKILL_DEFINITIONS provides rich skills with SP cost', () => {
  assert.ok(SKILL_DEFINITIONS.length >= 7);
  const flame = SKILL_DEFINITIONS.find(s => s.id === 'flame_burst');
  assert.ok(flame && flame.mpCost > 0 && flame.spCost > 0);
  const blood = SKILL_DEFINITIONS.find(s => s.id === 'blood_strike');
  assert.ok(blood && blood.mpCost > 0);
  const chain = SKILL_DEFINITIONS.find(s => s.id === 'chain_lightning');
  assert.ok(chain && chain.mpCost > 0);
});

test('Class skills are isolated at start: each class starts only with its own signature skill', () => {
  const warriorSkills = getInitialSkillsForClass('warrior');
  assert.deepEqual(warriorSkills, ['blood_strike']);
  assert.equal(isSkillUnlocked(warriorSkills, 'chain_lightning'), false);
  assert.equal(isSkillUnlocked(warriorSkills, 'shadow_ambush'), false);
  assert.equal(isSkillUnlocked(warriorSkills, 'flame_burst'), false);

  const mageSkills = getInitialSkillsForClass('mage');
  assert.deepEqual(mageSkills, ['chain_lightning']);
  assert.equal(isSkillUnlocked(mageSkills, 'blood_strike'), false);
  assert.equal(isSkillUnlocked(mageSkills, 'shadow_ambush'), false);

  const rogueSkills = getInitialSkillsForClass('rogue');
  assert.deepEqual(rogueSkills, ['shadow_ambush']);
  assert.equal(isSkillUnlocked(rogueSkills, 'blood_strike'), false);
  assert.equal(isSkillUnlocked(rogueSkills, 'chain_lightning'), false);
});

test('calcSkillEffect calculates blood strike, chain lightning, frost and barrier', () => {
  const blood = calcSkillEffect('blood_strike', 20, 2, 5);
  assert.ok(blood.damage > 25, 'Blood strike deals heavy damage');
  assert.ok(blood.heal > 0, 'Blood strike restores health');

  const chain = calcSkillEffect('chain_lightning', 20, 2, 5);
  assert.ok(chain.damage > 30, 'Chain lightning deals high piercing damage');

  const frost = calcSkillEffect('frost_nova', 15, 2, 5);
  assert.equal(frost.freeze, true, 'Frost nova freezes target');

  const barrier = calcSkillEffect('crystal_barrier', 15, 2, 5);
  assert.ok(barrier.shield > 25, 'Crystal barrier grants shield');
});

test('getShopInventory generates priced goods and scrolls for floor transitions', () => {
  const shop = getShopInventory(3);
  assert.ok(shop.length >= 4);
  const potion = shop.find(i => i.id === 'potion_hp');
  const scroll = shop.find(i => i.id === 'skill_point');
  assert.ok(potion && potion.cost > 0);
  assert.ok(scroll && scroll.cost > potion.cost);
});

test('HERO_CLASSES defines Warrior, Mage, and Rogue with unique skills and lore', () => {
  assert.ok(HERO_CLASSES.warrior);
  assert.ok(HERO_CLASSES.mage);
  assert.ok(HERO_CLASSES.rogue);

  assert.equal(HERO_CLASSES.warrior.uniqueSkillId, 'blood_strike');
  assert.equal(HERO_CLASSES.mage.uniqueSkillId, 'chain_lightning');
  assert.equal(HERO_CLASSES.rogue.uniqueSkillId, 'shadow_ambush');
});

test('GEAR_DROP_POOL has helmets, shields, weapons, and armors', () => {
  const slots = new Set(GEAR_DROP_POOL.map(g => g.slot));
  assert.ok(slots.has('weapon'));
  assert.ok(slots.has('helmet'));
  assert.ok(slots.has('shield'));
  assert.ok(slots.has('armor'));

  let dropCount = 0;
  for (let i = 0; i < 50; i++) {
    const item = rollEquipmentDrop(5);
    if (item) {
      dropCount++;
      assert.ok(item.tier <= 2);
    }
  }
  assert.ok(dropCount >= 2, 'Equipment drop works');
});

test('generateRandomEvent produces altar, locked_chest, trap, or shrine', () => {
  const event = generateRandomEvent(1);
  assert.ok(event.id);
  assert.ok(event.title.length > 0);
  assert.ok(event.options.length >= 2);
});

test('calcExpNeeded scales quadratically/exponentially per level', () => {
  const lvl1 = calcExpNeeded(1);
  const lvl2 = calcExpNeeded(2);
  assert.ok(lvl2 > lvl1);
});

test('midiToFreq computes standard pitches accurately', () => {
  assert.equal(midiToFreq(69), 440);
  assert.equal(midiToFreq(57), 220);
  assert.ok(Math.abs(midiToFreq(60) - 261.63) < 0.1);
});

test('getMusicThemeForFloor returns rich musical themes for all 4 dungeon tiers', () => {
  const t1 = getMusicThemeForFloor(1);
  assert.equal(t1.id, 'catacombs');
  assert.equal(t1.name, 'Эфирный Покой');
  assert.ok(t1.chordProgressions.length >= 4);
  assert.ok(t1.scaleFrequencies.length >= 7);
  assert.ok(t1.tempoSec >= 6 && t1.tempoSec <= 10);

  const t5 = getMusicThemeForFloor(5);
  assert.equal(t5.id, 'fungal_depths');
  assert.equal(t5.name, 'Изумрудный Сон');

  const t8 = getMusicThemeForFloor(8);
  assert.equal(t8.id, 'magma_rift');

  const t10 = getMusicThemeForFloor(10);
  assert.equal(t10.id, 'pantheon');
  assert.equal(t10.name, 'Сияние Вечности');
});

