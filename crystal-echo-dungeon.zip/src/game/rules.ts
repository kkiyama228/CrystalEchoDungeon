/**
 * Pure RPG logic, classes, equipment drops, events and map formulas for Dungeon Chronicles.
 */

export interface HeroClass {
  id: 'warrior' | 'mage' | 'rogue';
  name: string;
  title: string;
  iconSvg: string;
  desc: string;
  baseHp: number;
  baseMp: number;
  baseAtk: number;
  baseDef: number;
  baseCrit: number;
  uniqueSkillId: string;
  introStory: string[];
}

export const HERO_CLASSES: Record<string, HeroClass> = {
  warrior: {
    id: 'warrior',
    name: 'Воин',
    title: 'Падший Рыцарь Ордена Крови',
    iconSvg: 'sword_shield',
    desc: 'Мастер ближнего боя. Огромное здоровье, мощная броня и щит.',
    baseHp: 130,
    baseMp: 25,
    baseAtk: 16,
    baseDef: 10,
    baseCrit: 0.12,
    uniqueSkillId: 'blood_strike',
    introStory: [
      'Ваш орден был предан и предан мечу инквизицией императора.',
      'Лишь вы выжили в резне, сжимая в руках зазубренный бастард и расколотый щит.',
      'Слухи о древнем Кристалле Эха ведут вас в катакомбы — вы заставите глубины заплатить за кровь павших братьев.'
    ]
  },
  mage: {
    id: 'mage',
    name: 'Маг',
    title: 'Отступник Эфирной Академии',
    iconSvg: 'arcane_orb',
    desc: 'Владыка стихий и тайных знаний. Колоссальный запас маны и сокрушительные заклинания.',
    baseHp: 85,
    baseMp: 65,
    baseAtk: 12,
    baseDef: 5,
    baseCrit: 0.15,
    uniqueSkillId: 'chain_lightning',
    introStory: [
      'Академия сожгла ваши рукописи, назвав ваши исследования темного эфира ересью.',
      'Вы бежали в глубины заброшенных шахт, следуя за пульсацией глубинного зова.',
      'Здесь, в недрах земли, покоится Кристальное Сердце. Его сила вознесет вас над презренными архимагами.'
    ]
  },
  rogue: {
    id: 'rogue',
    name: 'Разбойник',
    title: 'Теневой Клинок Трущоб',
    iconSvg: 'dual_daggers',
    desc: 'Смертоносный убийца из засады. Высочайший шанс критического урона и уклонения.',
    baseHp: 100,
    baseMp: 35,
    baseAtk: 18,
    baseDef: 6,
    baseCrit: 0.32,
    uniqueSkillId: 'shadow_ambush',
    introStory: [
      'Вы украли карту катакомб у умирающего культиста в темном переулке столицы.',
      'На ней отмечены сокровищницы владык древности и корона Архи-Титана.',
      'Пока глупцы верят в проклятия, ваши отравленные клинки проложат дорогу к несметным богатствам.'
    ]
  }
};

export function getInitialSkillsForClass(classId: string): string[] {
  const cls = HERO_CLASSES[classId];
  return cls ? [cls.uniqueSkillId] : ['blood_strike'];
}

export interface EquipmentItem {
  id: string;
  name: string;
  slot: 'weapon' | 'helmet' | 'shield' | 'armor';
  atkBonus: number;
  defBonus: number;
  hpBonus: number;
  tier: number;
  visualId: string;
}

export const GEAR_DROP_POOL: EquipmentItem[] = [
  // Шлемы
  { id: 'helm_iron', name: 'Ржавый Бацинет', slot: 'helmet', atkBonus: 0, defBonus: 3, hpBonus: 10, tier: 1, visualId: 'helm_1' },
  { id: 'helm_winged', name: 'Крылатый Шлем Паладина', slot: 'helmet', atkBonus: 2, defBonus: 6, hpBonus: 25, tier: 2, visualId: 'helm_2' },
  { id: 'helm_demonic', name: 'Рогатый Венец Бездны', slot: 'helmet', atkBonus: 5, defBonus: 10, hpBonus: 45, tier: 3, visualId: 'helm_3' },

  // Щиты
  { id: 'shield_wood', name: 'Окованный Баклер', slot: 'shield', atkBonus: 0, defBonus: 4, hpBonus: 15, tier: 1, visualId: 'shield_1' },
  { id: 'shield_kite', name: 'Башенный Щит Инквизиции', slot: 'shield', atkBonus: 1, defBonus: 9, hpBonus: 35, tier: 2, visualId: 'shield_2' },
  { id: 'shield_aegis', name: 'Эгида Древнего Титана', slot: 'shield', atkBonus: 4, defBonus: 15, hpBonus: 60, tier: 3, visualId: 'shield_3' },

  // Оружие
  { id: 'sword_broad', name: 'Закаленный Палаш', slot: 'weapon', atkBonus: 6, defBonus: 1, hpBonus: 0, tier: 1, visualId: 'sword_1' },
  { id: 'sword_flame', name: 'Пламенеющий Эсток', slot: 'weapon', atkBonus: 12, defBonus: 2, hpBonus: 10, tier: 2, visualId: 'sword_2' },
  { id: 'sword_abyss', name: 'Клинок Погибели Бездны', slot: 'weapon', atkBonus: 20, defBonus: 4, hpBonus: 25, tier: 3, visualId: 'sword_3' },

  // Броня
  { id: 'armor_mail', name: 'Кольчуга Наемника', slot: 'armor', atkBonus: 1, defBonus: 5, hpBonus: 20, tier: 1, visualId: 'armor_1' },
  { id: 'armor_plate', name: 'Вороненые Латы Крестоносца', slot: 'armor', atkBonus: 2, defBonus: 11, hpBonus: 50, tier: 2, visualId: 'armor_2' },
  { id: 'armor_dread', name: 'Обсидиановый Панцирь Смерти', slot: 'armor', atkBonus: 5, defBonus: 18, hpBonus: 90, tier: 3, visualId: 'armor_3' },
];

export function rollEquipmentDrop(floor: number): EquipmentItem | null {
  if (Math.random() > 0.40) return null;
  const maxTier = floor <= 3 ? 1 : floor <= 7 ? 2 : 3;
  const eligible = GEAR_DROP_POOL.filter(item => item.tier <= maxTier);
  return eligible[Math.floor(Math.random() * eligible.length)];
}

export interface DungeonEvent {
  id: 'altar' | 'locked_chest' | 'trap' | 'shrine';
  title: string;
  desc: string;
  options: {
    label: string;
    action: string;
  }[];
}

export function generateRandomEvent(floor: number): DungeonEvent {
  const events: DungeonEvent[] = [
    {
      id: 'altar',
      title: 'Оскверненный Алтарь Крови',
      desc: 'В центре зала возвышается черный монолит, покрытый запекшейся кровью. Вы чувствуете пульсацию нечестивой мощи.',
      options: [
        { label: 'Пожертвовать 20 HP ради опыта (+80 EXP)', action: 'sacrifice_hp' },
        { label: 'Очистить рунами веры (Расход: 15 MP)', action: 'cleanse_mp' },
        { label: 'Пройти мимо с осторожностью', action: 'ignore' }
      ]
    },
    {
      id: 'locked_chest',
      title: 'Запертый Саркофаг с Печатью',
      desc: 'Тяжелый каменный ларец закован в цепи с массивным навесным замком. От него веет древним металлом.',
      options: [
        { label: 'Использовать ключ-отмычку (Шанс 70%)', action: 'pick_lock' },
        { label: 'Разбить замок силой (риск получить урон)', action: 'bash_lock' },
        { label: 'Оставить замок в покое', action: 'ignore' }
      ]
    },
    {
      id: 'trap',
      title: 'Скрытая Растяжка в Полумраке',
      desc: 'Щелчок под сапогом! Со свода пещеры срывается лезвие маятника и град стрел!',
      options: [
        { label: 'Сделать резкий кувырок вперед (Ловкость)', action: 'dodge_trap' },
        { label: 'Принять удар на доспех и щит (Защита)', action: 'shield_trap' }
      ]
    },
    {
      id: 'shrine',
      title: 'Чаша Синего Пламени Эфира',
      desc: 'Каменная чаша горит холодным мистическим огнем. Жидкость внутри нее светится первозданной энергией.',
      options: [
        { label: 'Испить из чаши (+Полное восстановление MP)', action: 'drink_shrine' },
        { label: 'Омыть клинок (+3 к атаке на 1 этаж)', action: 'bless_weapon' }
      ]
    }
  ];

  return events[Math.floor(Math.random() * events.length)];
}

export interface Biome {
  id: string;
  name: string;
  color: string;
  accent: string;
  bgGrad: string;
  cardBg: string;
  floors: number[];
  lore: string;
}

export const BIOMES: Biome[] = [
  {
    id: 'catacombs',
    name: 'Забытые Катакомбы Синего Эфира',
    color: '#06b6d4',
    accent: '#38bdf8',
    bgGrad: 'radial-gradient(circle at 50% 10%, #082f49 0%, #030712 70%)',
    cardBg: '#0f172a',
    floors: [1, 2, 3],
    lore: 'Каменные своды, поросшие лазурным мхом и тихими звонкими кристаллами эфира.'
  },
  {
    id: 'fungal_depths',
    name: 'Изумрудные Грибные Топи',
    color: '#10b981',
    accent: '#34d399',
    bgGrad: 'radial-gradient(circle at 50% 10%, #064e3b 0%, #021f17 70%)',
    cardBg: '#062d24',
    floors: [4, 5, 6],
    lore: 'Влажные гроты с мягкими светящимися спорами, изумрудным мхом и тихим шепотом корней.'
  },
  {
    id: 'magma_rift',
    name: 'Теплый Обсидиановый Разлом',
    color: '#f97316',
    accent: '#fb923c',
    bgGrad: 'radial-gradient(circle at 50% 10%, #451a03 0%, #0c0a09 70%)',
    cardBg: '#1c1917',
    floors: [7, 8, 9],
    lore: 'Бархатный обсидиан и медленно текущие теплые янтарные жилы древнего огня.'
  },
  {
    id: 'pantheon',
    name: 'Кристальный Пантеон Вечности',
    color: '#a855f7',
    accent: '#c084fc',
    bgGrad: 'radial-gradient(circle at 50% 10%, #2e1065 0%, #070312 70%)',
    cardBg: '#1a0b2e',
    floors: [10],
    lore: 'Аметистовый трон первородного Кристалла, мерцающий звездами бесконечности.'
  }
];

export function getBiomeForFloor(floor: number): Biome {
  const found = BIOMES.find(b => b.floors.includes(floor));
  return found || BIOMES[0];
}

export interface SkillDefinition {
  id: string;
  name: string;
  desc: string;
  mpCost: number;
  spCost: number;
  icon: string;
}

export const SKILL_DEFINITIONS: SkillDefinition[] = [
  { id: 'blood_strike', name: 'Удар Крови', desc: 'Мощный рубящий удар, наносящий 180% урона и лечащий на 25% от нанесенного урона.', mpCost: 10, spCost: 1, icon: 'sword_blood' },
  { id: 'chain_lightning', name: 'Цепная Молния', desc: 'Удар молнии с небес, игнорирующий 50% защиты монстра.', mpCost: 16, spCost: 1, icon: 'lightning' },
  { id: 'shadow_ambush', name: 'Теневая Засада', desc: 'Удар из невидимости с гарантированным критическим уроном x2.2.', mpCost: 12, spCost: 1, icon: 'dagger_poison' },
  { id: 'flame_burst', name: 'Огненный Всплеск', desc: 'Взрыв чистого пламени, наносящий тяжелый магический урон.', mpCost: 14, spCost: 1, icon: 'fireball' },
  { id: 'life_drain', name: 'Похищение Жизни', desc: 'Вытягивает жизненную силу из чудовища, восстанавливая HP.', mpCost: 12, spCost: 1, icon: 'life_drain' },
  { id: 'frost_nova', name: 'Ледяная Нова', desc: 'Замораживает противника, снижая его следующую атаку.', mpCost: 15, spCost: 1, icon: 'ice' },
  { id: 'crystal_barrier', name: 'Кристальный Барьер', desc: 'Создает щит, поглощающий входящий урон.', mpCost: 18, spCost: 1, icon: 'shield_barrier' }
];

export function isSkillUnlocked(unlockedSkills: string[], skillId: string): boolean {
  return unlockedSkills.includes(skillId);
}

export function calcSkillEffect(skillId: string, playerAtk: number, playerLvl: number, enemyDef: number) {
  let damage = 0;
  let heal = 0;
  let shield = 0;
  let freeze = false;

  switch (skillId) {
    case 'blood_strike':
      damage = Math.max(1, Math.round(playerAtk * 1.8 + playerLvl * 3 - enemyDef * 0.5));
      heal = Math.round(damage * 0.25);
      break;
    case 'chain_lightning':
      damage = Math.max(1, Math.round(playerAtk * 2.1 + playerLvl * 5 - enemyDef * 0.2));
      break;
    case 'shadow_ambush':
      damage = Math.max(1, Math.round(playerAtk * 2.3 + playerLvl * 4 - enemyDef * 0.4));
      break;
    case 'flame_burst':
      damage = Math.max(1, Math.round(playerAtk * 2.0 + playerLvl * 4 - enemyDef * 0.4));
      break;
    case 'life_drain':
      damage = Math.max(1, Math.round(playerAtk * 1.3 + playerLvl * 2 - enemyDef * 0.5));
      heal = Math.round(damage * 0.7);
      break;
    case 'frost_nova':
      damage = Math.max(1, Math.round(playerAtk * 1.4 + playerLvl * 2 - enemyDef * 0.6));
      freeze = true;
      break;
    case 'crystal_barrier':
      shield = Math.round(30 + playerLvl * 10 + playerAtk * 0.5);
      break;
    default:
      damage = Math.max(1, playerAtk - enemyDef);
  }

  return { damage, heal, shield, freeze };
}

export function calcExpNeeded(lvl: number): number {
  return Math.round(40 * Math.pow(1.5, lvl - 1));
}

export interface ShopItem {
  id: string;
  name: string;
  desc: string;
  cost: number;
  icon: string;
  type: 'heal' | 'mana' | 'atk' | 'def' | 'skill_point' | 'gear';
  value: number;
}

export function getShopInventory(floor: number): ShopItem[] {
  const baseCostMultiplier = 1 + (floor - 1) * 0.35;
  return [
    {
      id: 'potion_hp',
      name: 'Большое Зелье Здоровья',
      desc: 'Восстанавливает 55 HP',
      cost: Math.round(15 * baseCostMultiplier),
      icon: 'potion',
      type: 'heal',
      value: 55
    },
    {
      id: 'potion_mp',
      name: 'Эликсир Эфира',
      desc: 'Восстанавливает 35 MP',
      cost: Math.round(15 * baseCostMultiplier),
      icon: 'potion_mana',
      type: 'mana',
      value: 35
    },
    {
      id: 'scroll_atk',
      name: 'Свиток Ярости',
      desc: '+2 к постоянной атаке',
      cost: Math.round(45 * baseCostMultiplier),
      icon: 'scroll_red',
      type: 'atk',
      value: 2
    },
    {
      id: 'scroll_def',
      name: 'Руна Твердыни',
      desc: '+2 к постоянной защите',
      cost: Math.round(40 * baseCostMultiplier),
      icon: 'scroll_blue',
      type: 'def',
      value: 2
    },
    {
      id: 'skill_point',
      name: 'Гримуар Таинств',
      desc: '+1 очко умений',
      cost: Math.round(75 * baseCostMultiplier),
      icon: 'tome',
      type: 'skill_point',
      value: 1
    }
  ];
}

export interface MusicTheme {
  id: string;
  name: string;
  key: string;
  rootFreq: number;
  scaleFrequencies: number[];
  chordProgressions: number[][];
  tempoSec: number;
  combatIntensity: number;
}

export function midiToFreq(midi: number): number {
  return Math.round((440 * Math.pow(2, (midi - 69) / 12)) * 100) / 100;
}

export const BIOME_MUSIC_THEMES: Record<string, MusicTheme> = {
  catacombs: {
    id: 'catacombs',
    name: 'Эфирный Покой',
    key: 'D Dorian',
    rootFreq: 146.83,
    scaleFrequencies: [
      146.83, 164.81, 174.61, 196.00, 220.00, 261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 523.25
    ],
    chordProgressions: [
      [146.83, 220.00, 261.63, 329.63], // Dm9
      [116.54, 174.61, 220.00, 293.66], // Bbmaj7
      [130.81, 196.00, 261.63, 293.66], // C9
      [146.83, 220.00, 349.23, 440.00]  // Dm
    ],
    tempoSec: 7.5,
    combatIntensity: 1.15
  },
  fungal_depths: {
    id: 'fungal_depths',
    name: 'Изумрудный Сон',
    key: 'E Aeolian',
    rootFreq: 164.81,
    scaleFrequencies: [
      164.81, 196.00, 220.00, 246.94, 293.66, 329.63, 392.00, 440.00, 493.88, 587.33
    ],
    chordProgressions: [
      [164.81, 246.94, 293.66, 392.00], // Em9
      [130.81, 196.00, 246.94, 329.63], // Cmaj7
      [110.00, 164.81, 220.00, 293.66], // Am9
      [123.47, 185.00, 246.94, 293.66]  // Bm7
    ],
    tempoSec: 8.0,
    combatIntensity: 1.2
  },
  magma_rift: {
    id: 'magma_rift',
    name: 'Теплый Бархат',
    key: 'C Minor',
    rootFreq: 130.81,
    scaleFrequencies: [
      130.81, 155.56, 174.61, 196.00, 233.08, 261.63, 311.13, 349.23, 392.00, 466.16
    ],
    chordProgressions: [
      [130.81, 196.00, 233.08, 311.13], // Cm9
      [103.83, 155.56, 207.65, 261.63], // Abmaj7
      [87.31, 130.81, 174.61, 233.08],  // Fm9
      [98.00, 146.83, 196.00, 261.63]   // Gsus4
    ],
    tempoSec: 7.0,
    combatIntensity: 1.25
  },
  pantheon: {
    id: 'pantheon',
    name: 'Сияние Вечности',
    key: 'A Minor / Lydian',
    rootFreq: 220.00,
    scaleFrequencies: [
      220.00, 261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 587.33, 659.25, 783.99
    ],
    chordProgressions: [
      [110.00, 220.00, 261.63, 329.63], // Am9
      [87.31, 174.61, 246.94, 329.63],  // Fmaj7#11
      [146.83, 220.00, 293.66, 329.63], // Dsus2
      [164.81, 246.94, 293.66, 392.00]  // Em7
    ],
    tempoSec: 8.5,
    combatIntensity: 1.3
  }
};

export function getMusicThemeForFloor(floor: number): MusicTheme {
  if (floor <= 3) return BIOME_MUSIC_THEMES.catacombs;
  if (floor <= 6) return BIOME_MUSIC_THEMES.fungal_depths;
  if (floor <= 9) return BIOME_MUSIC_THEMES.magma_rift;
  return BIOME_MUSIC_THEMES.pantheon;
}

